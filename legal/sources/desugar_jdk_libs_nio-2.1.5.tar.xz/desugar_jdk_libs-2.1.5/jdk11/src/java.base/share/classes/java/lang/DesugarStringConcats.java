/*
 * Copyright (c) 2021 Google LLC
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.  Google designates this
 * particular file as subject to the "Classpath" exception as provided
 * by Google in the LICENSE file that accompanied this code.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 */
package java.lang;

/** The runtime library used for string concatenation. */
public class DesugarStringConcats {

  /**
   * Concatenate strings in a way compliant with the Javadoc for {@link
   * java.lang.invoke.StringConcatFactory#makeConcatWithConstants}.
   */
  public static String concat(Object[] runtimeTexts, String recipe, Object[] constants) {
    StringBuilder stringBuilder = new StringBuilder();
    for (int i = 0, runTimeTextIndex = 0, constantIndex = 0; i < recipe.length(); i++) {
      char c = recipe.charAt(i);
      if (c == '\1') {
        stringBuilder.append(runtimeTexts[runTimeTextIndex++]);
      } else if (c == '\2') {
        stringBuilder.append(constants[constantIndex++]);
      } else {
        stringBuilder.append(c);
      }
    }
    return stringBuilder.toString();
  }

  private DesugarStringConcats() {}
}
